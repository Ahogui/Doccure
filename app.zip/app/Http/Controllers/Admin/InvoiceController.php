<?php

namespace App\Http\Controllers\Admin;

use App\Models\Invoice;
use App\Models\InvoiceItem;
use App\Models\Patient;
use App\Models\Product;
use App\Models\ExamType;
use App\Models\Department;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Yajra\DataTables\Facades\DataTables;
use Illuminate\Support\Facades\Log;
use App\Http\Controllers\Controller;

class InvoiceController extends Controller
{
     // Liste des factures

    //  public function index()
    //  {
    //      $invoices = Invoice::with(['patient', 'department'])->paginate(10);
    //      $patients = Patient::all(); // Pour la liste déroulante des patients
    //      $departments = Department::all(); // Pour la liste déroulante des départements
    //      $products = Product::all();
    //      $examTypes = ExamType::all();

    //      return view('invoices.index', compact('invoices', 'patients', 'departments','products','examTypes' ));
    //  }
     public function index(Request $request)
    {
        if ($request->ajax()) {
            $data = Invoice::with('patient')->latest()->get();

            return DataTables::of($data)
                ->addIndexColumn()
                ->addColumn('invoice_number', function($row){
                    return 'FACT-'.str_pad($row->id, 6, '0', STR_PAD_LEFT);
                })
                ->addColumn('patient.name', function($row){
                    return $row->patient->full_name;
                })
                ->addColumn('invoice_date', function($row){
                    return $row->invoice_date->format('d/m/Y');
                })
                ->addColumn('grand_total', function($row){
                    return number_format($row->total_amount, 2);
                })
                ->addColumn('status', function($row){
                    return $row->status;
                })
                ->addColumn('action', function($row){
                    $btn = '<a href="javascript:void(0)" class="btn btn-sm btn-info viewbtn" data-id="'.$row->id.'">Voir</a>';
                    $btn .= ' <a href="javascript:void(0)" class="btn btn-sm btn-primary editbtn" data-id="'.$row->id.'">Editer</a>';
                    $btn .= ' <form action="'.route("invoices.destroy", $row->id).'" method="POST" style="display:inline">
                                '.csrf_field().'
                                '.method_field("DELETE").'
                                <button type="submit" class="btn btn-sm btn-danger" onclick="return confirm(\'Confirmer la suppression?\')">Supprimer</button>
                            </form>';
                    return $btn;
                })
                ->rawColumns(['action', 'status'])
                ->make(true);
        }

        $patients = Patient::all();
        $products = Product::all();

        return view('invoices.index', compact('patients', 'products'));
    }
    public function create($patientId)
    {
        $patient = Patient::with('currentDepartment')->findOrFail($patientId);

        return view('invoices.create', [
            'patient' => $patient,
            'products' => Product::where('quantity', '>', 0)->get(),
            'exams' => ExamType::active()->get(),
            'departments' => Department::with('headDoctor')->get(),
            'defaultDepartment' => $patient->currentDepartment
        ]);
    }

    // public function store(Request $request)
    // {
    //     $validated = $request->validate([
    //         'patient_id' => 'required|exists:patients,id',
    //         'department_id' => 'required|exists:departments,id',
    //         'payment_method' => 'required|in:cash,card,transfer,insurance',
    //         'items' => 'required|array|min:1',
    //         'items.*.type' => 'required|in:product,exam',
    //         'items.*.id' => 'required|integer',
    //         'items.*.quantity' => 'required|integer|min:1'
    //     ]);

    //     DB::beginTransaction();
    //     try {
    //         // Création de la facture
    //         $invoice = Invoice::create([
    //             'patient_id' => $validated['patient_id'],
    //             'department_id' => $validated['department_id'],
    //             'invoice_date' => now(),
    //             'payment_method' => $validated['payment_method'],
    //             'status' => 'pending',
    //             'total_amount' => 0
    //         ]);

    //         $total = 0;

    //         foreach ($validated['items'] as $item) {
    //             if ($item['type'] === 'product') {
    //                 $product = Product::findOrFail($item['id']);
    //                 $price = $product->price;
    //                 $name = $product->name;

    //                 // Vérification du stock
    //                 if ($product->quantity < $item['quantity']) {
    //                     throw new \Exception("Stock insuffisant pour $name");
    //                 }

    //                 // Mise à jour du stock
    //                 $product->decrement('quantity', $item['quantity']);

    //             } else {
    //                 $exam = ExamType::findOrFail($item['id']);
    //                 $price = $exam->price;
    //                 $name = $exam->name;
    //             }

    //             $itemTotal = $price * $item['quantity'];
    //             $total += $itemTotal;

    //             $invoice->items()->create([
    //                 'item_type' => $item['type'],
    //                 'item_id' => $item['id'],
    //                 'quantity' => $item['quantity'],
    //                 'unit_price' => $price,
    //                 'total' => $itemTotal,
    //                 'description' => $name
    //             ]);
    //         }

    //         // Mise à jour du total
    //         $invoice->update(['total_amount' => $total]);

    //         // Mise à jour du département du patient si différent
    //         $patient = Patient::find($validated['patient_id']);
    //         if ($patient->current_department_id != $validated['department_id']) {
    //             $patient->update(['current_department_id' => $validated['department_id']]);
    //         }

    //         DB::commit();

    //         return redirect()->route('invoices.show', $invoice->id)
    //             ->with('success', 'Facture créée avec succès!');

    //     } catch (\Exception $e) {
    //         DB::rollBack();
    //         return back()->withInput()
    //             ->with('error', 'Erreur: ' . $e->getMessage());
    //     }
    // }
    public function store(Request $request)
    {
        \DB::beginTransaction();
        try {
            // Validation des données
            $validated = $request->validate([
                'patient_id' => 'required|exists:patients,id',
                'invoice_date' => 'required|date',
                'status' => 'required|in:paid,unpaid',
                'payment_method' => 'required|in:cash,card,transfer,check',
                'products' => 'required|array|min:1',
                'products.*.product_id' => 'required|exists:products,id',
                'products.*.quantity' => 'required|integer|min:1',
                'products.*.unit_price' => 'required|numeric|min:0'
            ]);

            // Calcul du montant total
            $totalAmount = collect($request->products)->sum(function($product) {
                return $product['quantity'] * $product['unit_price'];
            });

            // Création de la facture
            $invoice = Invoice::create([
                'invoice_number' => 'FACT-' . str_pad(Invoice::max('id') + 1, 6, '0', STR_PAD_LEFT),
                'patient_id' => $request->patient_id,
                'invoice_date' => $request->invoice_date,
                'total_amount' => $totalAmount, // Utilisation du champ correct
                'status' => $request->status,
                'payment_method' => $request->payment_method
            ]);

            // Ajout des produits
            foreach ($request->products as $product) {
                $invoice->products()->attach($product['product_id'], [
                    'quantity' => $product['quantity'],
                    'unit_price' => $product['unit_price'],
                    'total' => $product['quantity'] * $product['unit_price']
                ]);
            }

            \DB::commit();

            return redirect()->route('invoices.index')
                        ->with('success', 'Facture créée avec succès!');

        } catch (\Exception $e) {
            \DB::rollBack();
            \Log::error("Erreur création facture: " . $e->getMessage());
            return back()->withInput()
                        ->with('error', 'Erreur lors de la création: ' . $e->getMessage());
        }
    }
    // Affichage d'une facture
    public function show($id)
    {
        $invoice = Invoice::with(['patient', 'items.item', 'department'])
            ->findOrFail($id);

        return view('invoices.show', compact('invoice'));
    }

    // Suppression
    public function destroy($id)
    {
        $invoice = Invoice::findOrFail($id);
        $invoice->delete();

        return redirect()->route('invoices.index')
            ->with('success', 'Facture supprimée avec succès');
    }

}
